function exponent=fast_exponentiation(X,a,n)
a_str=dec2bin(a);
x=X;
for i=2:1:length(a_str)
    x=mod(((x^2)),n);
    if(a_str(i)=='1')
        x=mod((x*X),n);
    end
end
exponent=mod(x,n);


        

        