clc;
clear all;
close all;

plaintext=input('Enter message:','s');
plaintext;
P=double(plaintext);
P
[e,d,n]=rsakeygen();
rsa_key=[e,d,n];
rsa_key

%encrytpion
for i=1:1:length(P)
    C(i)=mod(fast_exponentiation(P(i),e,n),n);
end
C
cipher=char(C);
cipher

%decrytpion
for i=1:1:length(C)
    P1(i)=mod(fast_exponentiation(C(i),d,n),n);
end

P1
received=char(P1);

received