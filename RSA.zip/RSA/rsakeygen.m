function [e,d,n]=rsakeygen()
p=randsample(primes(5000),1);
q=randsample(primes(5000),1);

n=p*q;
phi_n=(p-1)*(q-1);
e=randi(phi_n);
while(gcd(e,phi_n)~=1)
    e=randi(phi_n);
end

%calculating d(modulo-multiplicative inverse of e)
[G d]=gcd(e,phi_n);
d=mod(d,phi_n);


